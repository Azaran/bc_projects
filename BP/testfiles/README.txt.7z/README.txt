Slouzi pro veci kolem BP a ISP
